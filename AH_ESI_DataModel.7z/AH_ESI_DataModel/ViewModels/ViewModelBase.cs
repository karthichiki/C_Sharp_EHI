﻿using AH_ESI_DataModel.Stores;
using System;
using System.ComponentModel;

namespace AH_ESI_DataModel.ViewModels
{
    public class ViewModelBase : INotifyPropertyChanged
    {
        #region Member Variables
        public NavigationStoreBase NavigationStore { get; set; }
        public NotificationStoreBase NotificationStore { get; set; }

        #endregion

        #region INotifyPropertyChanged - Implementation

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string nameOfProperty)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameOfProperty));
        }
        #endregion

        #region Methods

        #region Set
        public void Set(NavigationStoreBase navigationStore, NotificationStoreBase notificationStore)
        {
            this.NavigationStore = navigationStore;
            this.NotificationStore = notificationStore;
        }
        #endregion

        #region SetStatus
        public void SetStatus(string message, int progress)
        {
            this.SetProgress(message, progress);
        }
        public void SetStatus(string message)
        {
            this.NotificationStore.UpdateStatus(message);
        }
        public void SetProgress(int progress)
        {
            this.NotificationStore.UpdateProgress(progress);
        }
        public void SetProgress(string message, int progress)
        {
            this.NotificationStore.Update(message, progress);
        }
        #endregion

        #endregion
    }
}
