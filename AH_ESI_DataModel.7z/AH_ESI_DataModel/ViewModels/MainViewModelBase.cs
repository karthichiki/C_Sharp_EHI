﻿using AH_ESI_DataModel.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace AH_ESI_DataModel.ViewModels
{
    public class MainViewModelBase: ViewModelBase
    {
        public ICommand ExitApplicationCommand { get; }

        public MainViewModelBase() {


            ExitApplicationCommand = new ExitApplicationCommand();
        }

    }
}
