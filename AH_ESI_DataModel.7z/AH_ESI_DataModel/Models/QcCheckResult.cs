﻿using AH_ESI_DataModel.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Models
{
    public class QcCheckResult
    {
        public string CheckName { get; set; }
        private eRS _status;
        public eRS Status { get { return _status; } set { _status = value; } }
        public string StatusToDisplay => GetResultStatus();



        public QcCheckResult() { }

        public string GetResultStatus()
        {
            return Enum.GetName(typeof(eRS), _status);
        }
        public string GetResultStatus(eRS status)
        {
            return Enum.GetName(typeof(eRS), status);
        }

    }
}
