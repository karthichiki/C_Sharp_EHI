﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Models
{
    public class CheckEvaluation
    {
        public CheckEvaluation() { }
        public CheckEvaluation(string name) { }
        public string Name { get; set; }
            

        public string Description { get; set; }
            

    }
}
