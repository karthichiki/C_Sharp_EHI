﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Models.Enums
{
    public static class Enums_Extensions
    {
        public static int AsInt(this eRS _enum) { return (int)_enum; }
        public static int AsInt(this eCatiaLicenseIds _enum) { return (int)_enum; }
        public static int AsInt(this eCatiaDocumentType _enum) { return (int)_enum; }
    }
}
