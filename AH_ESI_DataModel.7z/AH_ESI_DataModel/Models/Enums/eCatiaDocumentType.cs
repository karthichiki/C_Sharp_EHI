﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Models.Enums
{
    public enum eCatiaDocumentType
    {
        Unknown = 0,
        CATPart= 1,
        CATProduct= 2,
        CATDrawing= 3,
    }
}
