﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Models.Enums
{
    public enum eRS
    {
        Default = 0,
        OK = 1,
        NOK = 2,
        NA = 3,
        Indeterminate = 4,
        Success = 5,
        Failed = 6
    }
}
