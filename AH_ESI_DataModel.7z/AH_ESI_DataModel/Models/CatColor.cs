﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Models
{
    public class CatColor : IEquatable<CatColor>
    {
        public int Red = 0;
        public int Green = 0;
        public int Blue = 0;

        #region Constructors
        public CatColor()
        {

        }
        public CatColor(int r, int g, int b)
        {
            this.Red = r; this.Green = g; this.Blue = b;
        }

        public CatColor(string r, string g, string b)
        {
            r = r?.Trim();
            g = g?.Trim();
            b = b?.Trim();
            int.TryParse(r, out this.Red);
            int.TryParse(g, out this.Green);
            int.TryParse(b, out this.Blue);
        }
        #endregion

        #region GetCustomHashCode
        private int GetCustomHashCode()
        {
            int hashCode = base.GetHashCode();
            try
            {
                int hashCode_01 = this.Red.GetHashCode();
                int hashCode_02 = this.Green.GetHashCode();
                int hashCode_03 = this.Blue.GetHashCode();

                hashCode = hashCode_01 * hashCode_02 * hashCode_03 ;
            }
            catch (Exception) { }

            return unchecked(hashCode);
        }

        #endregion

        #region IsSameAs
        public bool IsSameAs(CatColor obj)
        {
            return this.Equals(obj);
        }
        #endregion

        #region Override Equal and Operators

        #region Equals
        public override bool Equals(object obj)
        {
            return this.Equals(obj as CatColor);
        }
        #endregion

        #region Equals
        public bool Equals(CatColor other)
        {
            if (other is null) return false;
            return this.GetHashCode() == other.GetHashCode() || 
                   (Red  == other.Red && 
                    Green == other.Green && 
                    Blue == other.Blue);
        }
        #endregion

        #region GetHashCode
        public override int GetHashCode()
        {
            return this.GetCustomHashCode();
        }
        #endregion

        #region ==
        public static bool operator ==(CatColor a, CatColor b)
        {
            if (ReferenceEquals(a, b)) return true;
            if (ReferenceEquals(a, null) || ReferenceEquals(b, null) || ReferenceEquals(null, null)) return false;
            return a.Equals(b);
        }
        #endregion

        #region !=
        public static bool operator !=(CatColor a, CatColor b)
        {
            return !(a == b);
        }
        #endregion

        #endregion

    }
}
