﻿using AH_ESI_DataModel.Models.Enums;
using AH_ESI_DataModel.Stores;
using AH_ESI_DataModel.ViewModels;
using AH_ESI_Utilities;
using INFITF;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using eRS = AH_ESI_DataModel.Models.Enums.eRS;

namespace AH_ESI_DataModel.Models
{
    public class QcCheck : QcCheckBase
    {
        public INFITF.Application CATIA;

        List<string> _Observations = new List<string>();
        List<string> _Results = new List<string>();

        public List<string> Observations => _Observations;

        private eRS _ResultStatus = eRS.Default;
        public eRS ResultStatus 
        { 
            get { return _ResultStatus;}
            set
            {
                _ResultStatus = value;
                Result = GetResult();
                OnPropertyChanged(nameof(ResultStatus)); }
        }

        private string _Result = string.Empty;
        public string Result 
        { 
            get { return _Result; } 
            set { _Result = value; OnPropertyChanged(nameof(Result)); }
        }

        public List<string> Results => _Results;
        public List<string> Results_Passed => GetResults(eRS.OK);
        public List<string> Results_Failed => GetResults(eRS.NOK);
        public List<string> Results_NA => GetResults(eRS.NA);
        public List<string> Results_Indeterminate => GetResults(eRS.Indeterminate);

        public virtual void Execute() { }

        public string PipeChar => Delimiters.Pipe;
        public string PipeCharDelimiter => " " + Delimiters.Pipe + " ";

        private List<string> GetResults(eRS resultStatus)
        {
            string resStatus = Enum.GetName(typeof(eRS), resultStatus);
            int resStatusAsNum = (int) resultStatus;
            var resultsFiltered =  Observations.Where(observationSentence => observationSentence.StartsWith(resStatus)).ToList();
            if (resultsFiltered is null) resultsFiltered = new List<string>();
            return resultsFiltered;
        }

        private string GetResult()
        {
            if (ResultStatus == eRS.Default) return "";
            return Enum.GetName(typeof(eRS), this.ResultStatus);
        }


        #region EvaluateCollectiveResult
        public eRS EvaluateCollectiveResult(bool clear = false)
        {
            eRS resultStatus = eRS.OK;

            bool found_OKs = false;
            bool found_NOKs = false;
            bool found_NAs = false;
            bool found_Indeterminates = false;

            this.Results.ForEach(result =>
            {
                if (!found_OKs && result.StartsWith(eRS.OK + PipeChar)) found_OKs = true;
                if (!found_NOKs && result.StartsWith(eRS.NOK + PipeChar)) found_NOKs = true;
                if (!found_NAs && result.StartsWith(eRS.NA + PipeChar)) found_NAs = true;
                if (!found_Indeterminates && result.StartsWith(eRS.Indeterminate + PipeChar)) found_Indeterminates = true;
            });
            if (found_NOKs || found_NAs || found_Indeterminates) resultStatus = eRS.NOK;

            if (clear) this.Results.Clear();

            return resultStatus;
        }
        #endregion
    }
}
