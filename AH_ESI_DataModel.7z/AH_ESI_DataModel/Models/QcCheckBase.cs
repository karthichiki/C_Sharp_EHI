﻿using AH_ESI_DataModel.Models.Enums;
using AH_ESI_DataModel.ViewModels;
using AH_ESI_Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Models
{
    public abstract class QcCheckBase: ViewModelBase
    {

        public string UC { get; set; } = string.Empty;
        public string ID { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public bool IsSelected { get; set; } = false;
        public bool DependsOnInputsFileFromInputsFolder { get; set; } = false;
        public bool AutoHeal { get; set; } = false;
        public bool AutoHealIsAppicable => AutoHeal ? true : false;

        public string ExecutionMode { get; set; } = string.Empty;
        public string ExecutionDuration { get; set; } = string.Empty;

        public string StartTime { get; set; } = string.Empty;
        public string EndTime { get; set; } = string.Empty;

        #region GetIdNameFromClassName
        public string GetIdFromClassName([CallerFilePath] string path = "")
        {
            string className = this.GetClassName(path);
            className.Extract(out string ucPrefix, out int ucNumber);
            return ucPrefix + " " + (ucNumber.ToString().Length == 1? "0" : "") + ucNumber.ToString();
        }
        #endregion

    }
}
