﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Commands
{
    public class ExitApplicationCommand : CommandBase
    {
        public ExitApplicationCommand() { }
        public override bool CanExecute(object parameter) { return true; }
        public override void Execute(object parameter)
        {
            System.Windows.Application.Current.Shutdown();
        }
    }
}
