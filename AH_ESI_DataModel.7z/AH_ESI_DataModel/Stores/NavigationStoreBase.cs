﻿using AH_ESI_DataModel.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Stores
{
    public class NavigationStoreBase
    {
        public event Action CurrentViewModelChanged;

        private ViewModelBase _CurrentViewModel;

        public ViewModelBase CurrentViewModel
        {
            get { return _CurrentViewModel; }
            set { _CurrentViewModel = value; }
        }
        private ViewModelBase _HomeViewModel;

        public ViewModelBase HomeViewModel
        {
            get { return _HomeViewModel; }
            set { _HomeViewModel = value; }
        }

        private void OnCurrentViewModelChanged()
        {
            CurrentViewModelChanged?.Invoke();
        }
    }
}
