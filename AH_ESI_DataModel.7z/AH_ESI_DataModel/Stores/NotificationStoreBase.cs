﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace AH_ESI_DataModel.Stores
{
    public class NotificationStoreBase
    {
        #region Member Variables

        #region Private Fields
        private int _progress = 0;
        private string _status = string.Empty;
        private List<string> _listLogs = new List<string>();
        private List<string> _listQcCheckResults = new List<string>();
        #endregion

        #region Properties
        public int Progress
        {
            get { return _progress; }
            set { _progress = value; OnCurrentProgressChanged(); }
        }

        public string Status
        {
            get { return _status; }
            set { _status = value; OnCurrentStatusChanged(); }
        }
        public List<string> Logs { get { return _listLogs; } set { _listLogs = value; OnCurrentLogsChanged(); } }
        public List<string> ListQcCheckResults { get { return _listQcCheckResults; } set { _listQcCheckResults = value; OnCurrentQcCheckResultsChanged(); } }

        #endregion

        #endregion

        #region Events
        public event Action CurrentProgressChanged;
        public event Action CurrentStatusChanged;
        public event Action CurrentQcCheckResultsChanged;
        public event Action CurrentLogsChanged;
        #endregion

        #region Methods

        #region OnCurrentStatusChanged
        public void OnCurrentStatusChanged()
        {
            CurrentStatusChanged?.Invoke();
        }
        #endregion

        #region OnCurrentProgressChanged
        public void OnCurrentProgressChanged()
        {
            CurrentProgressChanged?.Invoke();
        }
        #endregion

        #region OnCurrentQcCheckResultsChanged
        private void OnCurrentQcCheckResultsChanged()
        {
            CurrentQcCheckResultsChanged?.Invoke();
        }
        #endregion

        #region OnCurrentLogsChanged
        private void OnCurrentLogsChanged()
        {
            CurrentLogsChanged?.Invoke();
        }
        #endregion

        #region UpdateStatus
        public void UpdateStatus(string message)
        {
            Update(message);
        }
        public void UpdateStatus(string message, int progress)
        {
            Update(message, progress);
        }
        public void UpdateStatus(string message, double progress)
        {
            Update(message, (int)progress);
        }
        #endregion

        #region UpdateProgress

        #region UpdateProgress
        public void UpdateProgress(double progress)
        {
            Update((int)progress);
        }
        #endregion

        #region UpdateProgress
        public void UpdateProgress(int progress)
        {
            Update(progress);
        }
        #endregion

        #endregion

        #region Update

        #region Update
        public void Update(string message)
        {
            Update(() => { this.Status = message; });
        }
        #endregion

        #region Update
        public void Update(int progress)
        {
            Update(() => { this.Progress = progress; });
        }
        #endregion

        #region Update
        public void Update(string message, int progress)
        {
            Update(() => { this.Status = message; this.Progress = progress; });
        }
        #endregion

        #region Update
        public void Update(Action action)
        {
            try
            {
                Application.Current?.Dispatcher?.Invoke(() => action(), DispatcherPriority.Background);
            }
            catch { }
        }
        #endregion

        #endregion

        #endregion
    }
}
