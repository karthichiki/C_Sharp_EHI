﻿using AH_ESI_DataModel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel
{
    public static class UI
    {
        public static readonly string AH_ESI_Check = "AH ESI Check";
        private static readonly string Automation = "Automation";
        private static readonly string Inputs_Folder = "Inputs Folder";

        public static readonly string Title = $"{AH_ESI_Check}{Automation}";
        public static readonly string InputsFolderEnvVariableName = ($"{AH_ESI_Check}_{Inputs_Folder}");

        public static string AppPath ;
        public static string InputsFolderPath = " ";
        public static string InputsFolderPathSelectionMessage = "Please select \"Inputs\" folder";

        public static readonly string Deactivated = "Deactivated";
        public static readonly string Activated = "Activated";
        public static readonly string ComponentActivationState = "Component Activation State";

        public static CatColor Catia_DefaultColorApplied = new CatColor(210, 210, 255);
        public static CatColor Catia_NoColorApplied = new CatColor(255, 255, 255);

    }

    public class Delimiters
    {
        public static readonly string Pipe = "|";
        public static readonly string Semi = ";";
        public static readonly string Colon = ":";
        public static readonly string Comma = ",";
    }

    public class GsNames
    {
        public static readonly string ProtectionSet = "Protection Set";
        public static readonly string dummyName = "Dummy";
    }

}
