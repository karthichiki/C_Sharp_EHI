﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Services
{
    public class ServiceBase
    {

        public void Log(string message) {
            AH_ESI_Logger.Logger.GetInstance.Log(message);
        }
    }
}
