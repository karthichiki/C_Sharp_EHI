﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Constants
{
    public class TitleblockTextNames
    {
        public const string PartNumber = "TITLEBLOCK_PART_NUMBER";
        public const string Issue = "TITLEBLOCK_PART_ISSUE";
        public const string SheetNumber = "TITLEBLOCK_SHEET_NUMBER";
        public const string SheetScale = "TITLEBLOCK_SCALE";
        public const string SafetyClass1 = "TITLEBLOCK_SAFETY_CLASS_ACCORDING_TO";
        public const string SafetyClass2 = "TITLEBLOCK_SAFETY_CLASS";
        public const string MarkAccTo = "TITLEBLOCK_MARKING_ACCORDING_TO";
        public const string GeneralLimits = "TITLEBLOCK_GENERAL_LIMITS";
        public const string ProtectionAccTo = "TITLEBLOCK_PROTECTION_ACCORDING_TO";
        public const string SurfaceAccTo = "TITLEBLOCK_SURFACE_ACCORDING_TO";
        public const string Title = "TITLEBLOCK_TITLE_E";
        public const string NatoCode = "TITLEBLOCK_NATO_CODE";
        public const string DocumentType = "DOCUMENT_TYPE_RFD";
    }
}
