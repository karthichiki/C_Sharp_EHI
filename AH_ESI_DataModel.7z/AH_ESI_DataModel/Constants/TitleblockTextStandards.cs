﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Constants
{
    public class TitleblockTextStandards
    {
        public const string SheetScale = "N/A";
        public const string SafetyClass1 = "EI 04-06";
        public const string SafetyClass2 = "NC";
        public const string MarkAccTo = "HS5022";
        public const string GeneralLimits = "ISO2768-m";
        public const string ProtectionAccTo = "HS347";
        public const string SurfaceAccTo = "ISO1302";
        public const string NatoCode = "F0210";
        public const string DocumentType = "DRW";
    }
}
