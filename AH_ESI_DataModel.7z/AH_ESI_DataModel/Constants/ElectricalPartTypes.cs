﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_DataModel.Constants
{
    public class ElectricalPartTypes
    {
        public static readonly string Connector = "Connector";
        public static readonly string Connector1 = "Connecteur";
        public static readonly string Harness = "Harness";

    }
}
