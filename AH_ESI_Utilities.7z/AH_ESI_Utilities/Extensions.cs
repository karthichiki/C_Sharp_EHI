﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using ComTypes = System.Runtime.InteropServices.ComTypes;

namespace AH_ESI_Utilities
{
    [StructLayout(LayoutKind.Sequential)]
    public static class Extensions
    {
        #region GetClassName
        public static string GetClassName(this object obj, [CallerFilePath] string path = "")
        { return System.IO.Path.GetFileNameWithoutExtension(path); }
        #endregion

        #region RemoveSpaces
        public static string RemoveSpaces(this string inputString)
        {
            return inputString.Replace(" ",string.Empty)?.Trim();
        }
        #endregion

        #region RemoveUnderscore
        public static string RemoveUnderscore(this string inputString)
        {
            return inputString.Replace(" ", string.Empty)?.Trim();
        }
        #endregion

        #region RemoveHyphon
        public static string RemoveHyphon(this string inputString)
        {
            return inputString.Replace(" ", string.Empty)?.Trim();
        }
        #endregion

        #region Remove
        public static string Remove(this string inputString, object[] values)
        {
            return inputString?.Remove(values?.ToList());
        }
        #endregion

        #region Remove
        public static string Remove(this string inputString, List<object> values)
        {
            var valuesAsList = values?.Cast<string>().ToList();
            return inputString.Remove(valuesAsList);
        }
        #endregion

        #region Remove
        public static string Remove(this string inputString, List<string> values)
        {
            try
            {
                values?.ForEach(value => inputString = inputString.Replace(" ", string.Empty));
            }
            catch (Exception ex) { Console.WriteLine(ex.ToString()); }
            return inputString?.Trim(); ;
        }
        #endregion

        #region Extract

        #region Extract 1
        public static void Extract(this string inputString, out string letters, out int numbers)
        {
            inputString.Extract(out numbers, out letters);
        }
        #endregion

        #region Extract 2
        public static void Extract(this string inputString, out int numbers, out string letters)
        {
            numbers = 0; letters = "";
            inputString.Extract(out string nums, out string letrs);
            int.TryParse(nums, out int num);
            numbers = num; letters = letrs;
        }
        #endregion

        #region Extract 3
        public static void Extract(this string inputString, out string numbers, out string letters)
        {
            numbers = letters = "";
            var arrChars = inputString.ToCharArray();
            for (int i = 0; i < arrChars.Length; i++)
            {
                char c = arrChars[i];
                if (char.IsDigit(c) || c == '.' || c == '-') numbers += c.ToString();
                if (char.IsLetter(c)) letters += c.ToString();
            }
        }
        #endregion

        #endregion

        #region GetFile
        public static string GetFile(this DirectoryInfo directoryInfo, string searchingFileName)
        {
            return SearchAndGetFileFrom(directoryInfo.FullName, searchingFileName);
        }
        #endregion

        #region SearchAndGetFileFrom
        public static string SearchAndGetFileFrom(string targetFolderPath, string searchingFileNameWithExtension, List<string> listOfFileExtensionsTobeConsidered = null)
        {
            List<string> listOfFilesFound = new List<string>();
            string excelFilePath = "";
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(targetFolderPath);
                if (!directoryInfo.Exists) return excelFilePath;

                var searchingFileExtension = Path.GetExtension(searchingFileNameWithExtension)?.Replace(".", "");
                if (listOfFileExtensionsTobeConsidered is null) listOfFileExtensionsTobeConsidered = new List<string>();

                listOfFileExtensionsTobeConsidered.Add(searchingFileExtension);
                listOfFileExtensionsTobeConsidered = listOfFileExtensionsTobeConsidered.Distinct().ToList();
                listOfFileExtensionsTobeConsidered = listOfFileExtensionsTobeConsidered.ToUpper();

                var searchingFileName = Path.GetFileNameWithoutExtension(searchingFileNameWithExtension)?.Trim()?.ToUpper();

                var allFiles = System.IO.Directory.GetFiles(directoryInfo.FullName, ".", SearchOption.AllDirectories).ToList();

                allFiles?.ForEach(ffn => {
                    var fileName = Path.GetFileNameWithoutExtension(ffn)?.Trim()?.ToUpper();
                    if (searchingFileName == fileName)
                    {
                        var fileExtension = Path.GetExtension(ffn)?.Trim()?.ToUpper();
                        if (listOfFileExtensionsTobeConsidered.Contains(fileExtension.ToUpper()) ||
                            listOfFileExtensionsTobeConsidered.Contains(fileExtension.ToLower()) || 
                            listOfFileExtensionsTobeConsidered.Contains(fileExtension.ToUpper().Replace(".","")) ||
                            listOfFileExtensionsTobeConsidered.Contains(fileExtension.ToLower().Replace(".", "")))
                        {
                            listOfFilesFound.Add(ffn);
                        }
                    }
                });
            }
            catch { }

            excelFilePath = listOfFilesFound?.FirstOrDefault();

            return excelFilePath;
        }
        #endregion

        #region GetFile
        public static string GetFile(this DirectoryInfo directoryInfo, string partNumber,List<string> listOfFileExtensionsTobeConsidered)
        {
            return SearchAndGetFileFrom(directoryInfo.FullName, listOfFileExtensionsTobeConsidered, partNumber );
        }
        #endregion

        #region SearchAndGetFileFrom
        public static string SearchAndGetFileFrom(string targetFolderPath, List<string> listOfFileExtensionsTobeConsidered, string partNumber)
        {
            List<string> listOfFilesFound = new List<string>();
            string excelFilePath = "";
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(targetFolderPath);
                if (!directoryInfo.Exists) return excelFilePath;

                //var searchingFileExtension = Path.GetExtension(searchingFileNameWithExtension)?.Replace(".", "");
                //if (listOfFileExtensionsTobeConsidered is null) listOfFileExtensionsTobeConsidered = new List<string>();

                //listOfFileExtensionsTobeConsidered.Add(searchingFileExtension);
                //listOfFileExtensionsTobeConsidered = listOfFileExtensionsTobeConsidered.Distinct().ToList();
                //listOfFileExtensionsTobeConsidered = listOfFileExtensionsTobeConsidered.ToUpper();

                //var searchingFileName = Path.GetFileNameWithoutExtension(searchingFileNameWithExtension)?.Trim()?.ToUpper();

                var allFiles = System.IO.Directory.GetFiles(directoryInfo.FullName, ".", SearchOption.AllDirectories).ToList();
                allFiles = allFiles.OrderByDescending(f => f).ToList();
                allFiles?.ForEach(ffn => {
                    var fileName = Path.GetFileNameWithoutExtension(ffn)?.Trim()?.Replace(" ","").ToUpper();
                    
                    if ( fileName.Contains("EXTRACT") && fileName.Contains("BDELEC") && fileName.Contains("EHI") && fileName.Contains(partNumber))
                    {
                        var fileExtension = Path.GetExtension(ffn)?.Trim()?.ToUpper();
                        if (listOfFileExtensionsTobeConsidered.Contains(fileExtension.ToUpper()) ||
                            listOfFileExtensionsTobeConsidered.Contains(fileExtension.ToLower()) ||
                            listOfFileExtensionsTobeConsidered.Contains(fileExtension.ToUpper().Replace(".", "")) ||
                            listOfFileExtensionsTobeConsidered.Contains(fileExtension.ToLower().Replace(".", "")))
                        {
                            listOfFilesFound.Add(ffn);
                        }
                    }
                });
            }
            catch { }

            excelFilePath = listOfFilesFound?.FirstOrDefault();

            return excelFilePath;
        }
        #endregion

        #region ToUpper
        public static List<string> ToUpper(this List<string> listStrings)
        {
            return listStrings.ConvertToLowerOrUpperCase(lowerCase: false);
        }
        #endregion

        #region ToLower
        public static List<string> ToLower(this List<string> listStrings)
        {
            return listStrings.ConvertToLowerOrUpperCase(lowerCase:true);
        }
        #endregion

        #region ConvertToLowerOrUpperCase
        public static List<string> ConvertToLowerOrUpperCase(this List<string> listStrings, bool lowerCase)
        {
            if (listStrings is null is false)
            {
                for (int i = 0; i < listStrings.Count; i++)
                {
                    if (!string.IsNullOrWhiteSpace(listStrings[i]))
                        listStrings[i] = lowerCase ? listStrings[i].ToLower() : listStrings[i].ToUpper();
                }
            }
            return listStrings;
        }
        #endregion
    }


}
