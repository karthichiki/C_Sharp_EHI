﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;

namespace AH_ESI_Utilities
{
    public class Utilities
    {

        public static string RemoveInstanceNumber(string instanceName, char instanceChar = '.')
        {
            if (string.IsNullOrEmpty(instanceName)) return instanceName;
            var index = instanceName.LastIndexOf(instanceChar);
            if (index != -1) instanceName = instanceName.Substring(0, index);
            return instanceName;
        }
        #region GetWireType
        public static string GetHarnessWireType(string harnessName)
        {
            string wireType = string.Empty;
            var listOfSplitString = harnessName.Split(' ').ToList();
            var wireType1 = harnessName.Split(' ').Last();
            string pattern = @"^\d[A-Z]{1,3}$";

            if (Regex.IsMatch(wireType1, pattern)) wireType = wireType1;
            else if (!Regex.IsMatch(wireType1, pattern))
            {
                foreach (string item in listOfSplitString)
                {
                    if (Regex.IsMatch(item, pattern)) { wireType = item; break; }
                }
            }
            if (wireType != string.Empty) { return wireType; }
            if (wireType == string.Empty)
            {
                var splitText = harnessName.Split('-').ToList();
                foreach (string textSearch in splitText)
                {
                    if (Regex.IsMatch(textSearch, pattern)) { wireType = textSearch; break; }
                    else if (textSearch.ToUpper().Contains("HARNESS") && (textSearch.Length > 7))
                    {
                        wireType = textSearch.Substring(textSearch.ToUpper().IndexOf("HARNESS") + 7);
                        if (wireType != string.Empty) { wireType = wireType.Trim(); break; }
                    }
                }
            }
            return wireType;
        }
        #endregion
    }
}
