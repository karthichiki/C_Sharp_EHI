﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_Logger
{
    public class Logger
    {
        #region Member Variables
        private string logFolder;
        private string logFileName;
        private string logFileFullName;
        private const string logFileExtension = "log";
        #endregion

        #region Singleton Pattern Constructor
        private static Logger _Instance;

        public static Logger GetInstance
        {
            get
            {
                CreateLogger();
                return _Instance;
            }
        }
        #endregion

        #region Constructor
        private Logger()
        {
            SetLogFile(System.IO.Path.GetTempPath(), GetLogFileName());
        }

        #endregion

        #region Methods

        #region CreateLogger
        public static void CreateLogger()
        {
            if (_Instance is null)
            {
                _Instance = new Logger();
                try
                {
                    if (System.IO.File.Exists(_Instance.logFileFullName))
                        System.IO.File.Delete(_Instance.logFileFullName);
                }
                catch (Exception ex) { }
            }
        }
        #endregion

        #region Log
        public void Log(string message)
        {
            try
            {
                System.IO.StreamWriter writer = new System.IO.StreamWriter(logFileFullName, append: true);
                writer.WriteLine(message);
                writer.Close();
            }
            catch (Exception ex) { }
        }
        #endregion

        #region GetLogFileName
        private string GetLogFileName()
        {
            string tempFileName = System.IO.Path.GetTempFileName();
            try
            {
                if (System.IO.File.Exists(tempFileName))
                    System.IO.File.Delete(tempFileName);
            }
            catch (Exception ex) { }
            tempFileName = System.IO.Path.ChangeExtension(tempFileName, logFileExtension);

            return tempFileName;
        }
        #endregion

        #region SetLogFileFolderPath
        public void SetLogFileFolderPath(string newFolderPath)
        {
            SetLogFile(newFolderPath, logFileName);
        }
        #endregion

        #region SetLogFileName
        public void SetLogFileName(string newFileName, bool deletePreviousLogFile = true)
        {
            SetLogFile(logFolder, newFileName);
        }
        #endregion

        #region SetLogFileName
        public void SetLogFileName(string newFolder, string newFileName, bool deletePreviousLogFile = true)
        {
            string logFileOld = logFileFullName;
            SetLogFile(newFolder, newFileName);
            if (deletePreviousLogFile && System.IO.File.Exists(logFileOld))
            {
                try
                {
                    System.IO.File.Delete(logFileOld);
                }
                catch (Exception ex) { }
            }
        }
        #endregion

        #region SetLogFile
        private void SetLogFile(string folderPath, string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
                fileName = GetLogFileName();
            logFileName = fileName;
            logFolder = folderPath;
            logFileFullName = System.IO.Path.Combine(folderPath, fileName);
            logFileFullName = System.IO.Path.ChangeExtension(logFileFullName, logFileExtension);
        }
        #endregion

        #endregion
    }
}
