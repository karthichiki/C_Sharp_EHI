﻿using AH_ESI_BusinessLogic.ViewModels;
using AH_ESI_Check_Automation.ViewModels;
using AH_ESI_Check_Automation.Views;
using AH_ESI_DataModel;
using AH_ESI_DataModel.Stores;
using AH_ESI_Logger;
using System;
using System.Windows;

namespace AH_ESI_Check_Automation
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        #region Private member variables
        private readonly NavigationStoreBase _navigationStore = new NavigationStoreBase();
        private readonly NotificationStoreBase _notificationStore = new NotificationStoreBase();
        #endregion

        #region Constructors

        public App()
        {
            _navigationStore = new NavigationStoreBase();
            string startDateTime = DateTime.Now.ToString("yyyy_dd_mm_hh_mm_ss");
            Logger.CreateLogger();
            Logger.GetInstance.SetLogFileName(UI.Title.Replace(" ", "") + startDateTime);
            this.Log("===============================================================");
            this.Log($"\t\t \"{UI.Title}\" started... at {startDateTime}");
            this.Log("===============================================================");
            //string folderPath = System.AppDomain.CurrentDomain.BaseDirectory;
            //logger.SetLogFileFolderPath(folderPath);
        }
        #endregion

        #region Methods

        #region ShowMainWindow
        private void ShowMainWindow()
        {
            UI.AppPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            HomeViewModel homeViewModel = new HomeViewModel(_navigationStore, _notificationStore);
            _navigationStore.HomeViewModel = _navigationStore.CurrentViewModel = homeViewModel;
            homeViewModel.InitializeChecksAsync();
            homeViewModel.CollectOpenedCatiaDocumentsAsync();
            MainWindow mainWindow = new MainWindow()
            {
                DataContext = new MainWindowViewModel(_navigationStore, _notificationStore),
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Title = UI.Title,
                Width = 1000,
                Height = 400
            };
            this.MainWindow = mainWindow;
            this.MainWindow.Show();
        }
        #endregion

        #region Log
        private void Log(string message)
        {
            Logger.GetInstance.Log(message);
        }
        #endregion

        #endregion

        #region Events

        #region OnStartup
        protected override void OnStartup(StartupEventArgs e)
        {
            this.ShowMainWindow();
            base.OnStartup(e);
        }
        #endregion

        #endregion

    }
}
