﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_CATIA.Models
{
    public class CatiaProductTypes
    {
        public static readonly string Component = "Component";
        public static readonly string Product = "Product";
        public static readonly string Part = "Part";
    }
}
