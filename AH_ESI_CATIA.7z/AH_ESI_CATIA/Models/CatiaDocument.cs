﻿
using AH_ESI_CATIA.Services;
using AH_ESI_DataModel.Models.Enums;
using DRAFTINGITF;
using INFITF;
using MECMOD;
using ProductStructureTypeLib;
using System;
using System.Reflection;
using System.Xml.Linq;

namespace AH_ESI_CATIA.Models
{
    public class CatiaDocument
    {
        #region Member Variables
        public bool IsActive => IsCurrentlyActive();

        public string Active  => IsCurrentlyActive() ? "Active" : string.Empty;

        public bool IsSelected { get; set; } = false;
        public int Index { get; private set; } = 0;
        public string Name { get; private set; } = string.Empty;
        public string Type { get; private set; } = string.Empty;
        private Document _document = null;
        #endregion

        #region Constructors
        public CatiaDocument(int serialNumber, Document document)
        {
            if (document is null) return;
            Index = serialNumber;
            _document = document;
            Initialize();
        }
        #endregion

        #region Methods

        #region Initialize
        void Initialize()
        {
            Product product = null;
            if (_document is PartDocument)
            {
                Type = Enum.GetName(typeof(eCatiaDocumentType), eCatiaDocumentType.CATPart);
                product = (_document as PartDocument).Product;
            }
            else if (_document is ProductDocument)
            {
                Type = Enum.GetName(typeof(eCatiaDocumentType), eCatiaDocumentType.CATProduct);
                product = (_document as ProductDocument).Product;
            }
            else if (_document is DrawingDocument)
            {
                Type = Enum.GetName(typeof(eCatiaDocumentType), eCatiaDocumentType.CATDrawing);
            }

            Name = product is null ? _document?.get_Name() : product.get_Name();
            Name = System.IO.Path.GetFileNameWithoutExtension(Name);
        }
        #endregion

        #region GetDocument
        public Document GetDocument()
        {
            return _document;
        }
        #endregion

        #region IsCurrentlyActive
        private bool IsCurrentlyActive()
        {
            if (_document is null) return false;
            var CATIA = _document.Application;
            if (CATIA.Windows.Count == 0) return false;
            var activeWindow = CATIA.ActiveWindow;
            _document.Activate();
            var documentWindow = CATIA.ActiveWindow;
            activeWindow.Activate();
            return documentWindow.get_Caption() == activeWindow.get_Caption();
        }
        #endregion

        #endregion

    }
}
