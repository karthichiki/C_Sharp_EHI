﻿using AH_ESI_Utilities;
using INFITF;
using MECMOD;
using ProductStructureTypeLib;
using System;

namespace AH_ESI_CATIA.Models
{
    public class CatiaProductDetails
    {
        #region Member Variables

        #region Private Variables
        private PartDocument m_PartDoc = null;
        private Part m_Part = null;
        private Product m_RootProduct = null;
        private Product m_ProductInstance = null;
        private Product m_ParentProduct = null;
        private Selection m_RootProductSelection = null;
        private ProductDocument m_RootProductDoc = null;
        private string m_ProductType = null;
        #endregion

        #region Properties
        public PartDocument PartDoc => m_PartDoc;
        public Part Part => m_Part;
        public Product ProductInstance => m_ProductInstance;
        public Product RootProduct => m_RootProduct;
        public Product ParentProduct => m_ParentProduct;
        public Selection RootProductSelection => m_RootProductSelection;
        public ProductDocument RootProductDocument => m_RootProductDoc;
        public string TreePath { get; private set; }
        public int Level => GetTreeLevel();
        public string ProductType => GetProductType();
        public string InstanceName => GetInstanceName();
        public string PartNumber => GetPartNumber();
        #endregion

        #endregion

        #region Constructor
        public CatiaProductDetails(Product product, Product parentProduct, Product rootProduct)
        {
            this.Initialize(product, parentProduct, rootProduct);
        }
        #endregion

        #region Methods

        #region Initialize

        #region Initialize 1
        private void Initialize(Product product, Product parentProduct, Product rootProduct)
        {
            if (product is null || rootProduct is null) return;
            Document document = null; PartDocument partDoc = null;
            try { document = product.ReferenceProduct.Parent as Document; }
            catch (Exception ex) { document = null; }
            partDoc = document as PartDocument;
            this.Initialize(product, parentProduct, rootProduct, partDoc);
        }
        #endregion

        #region Initialize 2
        private void Initialize(Product product, Product parentProduct, Product rootProduct, PartDocument partDoc)
        {
            this.m_RootProduct = rootProduct;
            this.m_ProductInstance = product;
            this.m_ParentProduct = parentProduct;
            this.m_PartDoc = partDoc;
            this.m_Part = this.m_PartDoc?.Part;
            this.m_ProductType = GetProductType();
            if (m_RootProduct != null)
            {
                Document document = m_RootProduct.Parent as Document;
                this.m_RootProductDoc = document as ProductDocument;
                this.m_RootProductSelection = document.Selection;
                this.GetProductInstanceTreePath();
            }
        }
        #endregion

        #endregion


        #region GetProductInstanceTreePath
        private void GetProductInstanceTreePath()
        {
            try
            {
                m_RootProductSelection.Clear();
                m_RootProductSelection.Add(m_ProductInstance);
                SelectedElement selectedElement = this.m_RootProductSelection.Item(1);
                this.TreePath = selectedElement.Reference.DisplayName;
                this.TreePath = TreePath?.Trim();
                m_RootProductSelection.Clear();
            }
            catch (Exception ex) { this.TreePath = ""; }
        }
        #endregion

        #region GetTreeLevel
        private int GetTreeLevel()
        {
            if (string.IsNullOrEmpty(TreePath)) return 0;
            int level = TreePath.Length - TreePath.Replace("/", "").Length - 1;
            return level;
        }
        #endregion

        #region GetProductType
        public string GetProductType()
        {
            string productType = "Unknown";
            try
            {
                string prodName = m_ProductInstance.get_Name();
                Document m_ProductInstanceDocument = m_ProductInstance?.ReferenceProduct?.Parent as Document;
                string productDoc_Name = m_ProductInstanceDocument?.get_Name();
                string productDoc_HashCode = m_ProductInstanceDocument?.GetHashCode().ToString();

                Document m_ProductInstanceParentDocument = m_ParentProduct?.ReferenceProduct?.Parent as Document;
                string productDocParent_Name = m_ProductInstanceParentDocument?.get_Name();
                string productDocParent_HashCode = m_ProductInstanceParentDocument?.GetHashCode().ToString();

                if (m_ProductInstanceDocument is PartDocument) productType = CatiaProductTypes.Part;
                if (m_ProductInstanceDocument is ProductDocument) productType = CatiaProductTypes.Product;
                if (productDoc_Name == productDocParent_Name) productType = CatiaProductTypes.Component;
            }
            catch 
            {
                Console.Error.WriteLine("");
            }

            return productType;
        }

        #endregion

        #region GetPartNumber
        private string GetPartNumber()
        {
            string partNumber = string.Empty;
            try { partNumber = this.ProductInstance?.get_PartNumber(); }
            catch { }
            return partNumber;
        }
        #endregion

        #region GetInstanceName
        private string GetInstanceName()
        {
            string name = string.Empty;
            try { name = this.ProductInstance?.get_Name(); }
            catch { }
            return name;
        }
        #endregion       
        #endregion
    }
}
