﻿using AH_ESI_CATIA.Models;
using AH_ESI_DataModel.Services;
using DRAFTINGITF;
using HybridShapeTypeLib;
using INFITF;
using MECMOD;
using PARTITF;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace AH_ESI_CATIA.Services
{
    public class CatiaService : ServiceBase
    {
        public static INFITF.Application CATIA;

        #region Member Variables
        #endregion

        #region Constructors
        #region Singleton Constructor
        private static CatiaService _instance = null;
        public static CatiaService GetInstance 
        {
            get
            {
                if (_instance is null) _instance = new CatiaService();
                return _instance;
            }
        }
        #endregion
        private CatiaService() {
            GetCATIA();
        }
        #endregion


        #region Methods

        #region GetCATIA
        public static bool GetCATIA()
        {
            if (CATIA != null) return true;
            try
            {
                CATIA = Marshal.GetActiveObject("CATIA.Application") as INFITF.Application;
            }
            catch { }
            return CATIA != null;
        }
        #endregion

        #region CollectProductDetailsFrom
        public void CollectProductDetailsFrom(Product rootProduct, out List<CatiaProductDetails> listProductDetails)
        {
            listProductDetails = new List<CatiaProductDetails>();
            if (rootProduct is null) return;

            var catiaProductDetails = new CatiaProductDetails(rootProduct, parentProduct:null, rootProduct);
            if (catiaProductDetails != null) listProductDetails.Add(catiaProductDetails);

            //CollectProductDetailsFromChild(rootProduct, null, rootProduct, ref listProductDetails);
            foreach (Product childProduct in rootProduct.Products)
                CollectProductDetailsFromChild(childProduct, rootProduct, rootProduct, ref listProductDetails);

        }
        #endregion

        #region CollectProductDetailsFromChild
        public void CollectProductDetailsFromChild(Product product, Product parentProduct, Product rootProduct, ref List<CatiaProductDetails> listProductDetails)
        {
            if (listProductDetails is null) listProductDetails = new List<CatiaProductDetails>();

            var catiaProductDetails = new CatiaProductDetails(product, parentProduct, rootProduct);
            if (catiaProductDetails != null)
                listProductDetails.Add(catiaProductDetails);

            if (product.Products.Count > 0)
            {
                foreach (Product childProduct in product.Products)
                    CollectProductDetailsFromChild(childProduct, product, rootProduct, ref listProductDetails);
            }
        }
        #endregion

        #region GetCatiaWindowFor
        public static Window GetCatiaWindowFor(Document document)
        {
            var CATIA = document.Application;
            if (CATIA is null) return null;
            if (CATIA.Windows.Count == 0) return null;
            var currentActiveWindow = CATIA.ActiveWindow;
            document.Activate();
            var documentWindow = CATIA.ActiveWindow;
            currentActiveWindow.Activate();
            return documentWindow;
        }
        #endregion

        #region GetParentProduct
        public static Product GetParentProduct(Product product)
        {
            if (product is null) return null;
            Product parentProduct = null;
            AnyObject parent = product;
            while (parentProduct is null && parent is INFITF.Application is false)
            {
                parent = parent.Parent as AnyObject;
                parentProduct = parent as Product;
                if (parentProduct != null || parent is INFITF.Application) break;
            }
            return parentProduct;
        }

        #endregion

        #region IsVisibleOnScreen
        public static bool IsVisibleOnScreen(PartDocument partDoc, AnyObject anyObjectToCheck)
        {
            return IsVisibleOnScreen(partDoc as Document, anyObjectToCheck);
        }
        public static bool IsVisibleOnScreen(ProductDocument productDoc, AnyObject anyObjectToCheck)
        {
            return IsVisibleOnScreen(productDoc as Document, anyObjectToCheck);
        }
        public static bool IsVisibleOnScreen(DrawingDocument drawingDoc, AnyObject anyObjectToCheck)
        {
            return IsVisibleOnScreen(drawingDoc as Document, anyObjectToCheck);
        }
        public static bool IsVisibleOnScreen(Document document, AnyObject anyObjectToCheck)
        {
            bool isVisble = true;
            var catia = anyObjectToCheck?.Application;
            AnyObject parent = anyObjectToCheck;
            while (parent != null)
            {
                if (parent is INFITF.Application || parent is Document || !isVisble) break;
                string parentName = parent?.get_Name();
                bool skip = parentName.Equals("ShapeFactory", StringComparison.InvariantCultureIgnoreCase) ||
                            parentName.Equals("HybridShapeFactory", StringComparison.InvariantCultureIgnoreCase);
                if (!skip)
                    isVisble = IsVisible(document, parent);
                parent = parent.Parent as AnyObject;
            }
            document.Selection.Clear();
            return isVisble;
        }
        #endregion

        #region IsVisible

        public static bool IsVisible(PartDocument partDoc, AnyObject anyObjectToCheck)
        {
            return IsVisible(partDoc as Document, anyObjectToCheck);
        }
        public static bool IsVisible(ProductDocument productDoc, AnyObject anyObjectToCheck)
        {
            return IsVisible(productDoc as Document, anyObjectToCheck);
        }
        public static bool IsVisible(DrawingDocument drawingDoc, AnyObject anyObjectToCheck)
        {
            return IsVisible(drawingDoc as Document, anyObjectToCheck);
        }
        public static bool IsVisible(Document document, AnyObject anyObjectToCheck)
        {
            return IsVisible(anyObjectToCheck, document.Selection);
        }

        #region IsVisible
        public static bool IsVisible(Selection selection, AnyObject anyObjectToCheck)
        {
            return IsVisible(anyObjectToCheck, selection);
        }
        public static bool IsVisible(AnyObject anyObjectToCheck, Selection selection)
        {
            bool isVisble = false;
            CatVisPropertyShow catVisPropertyShow = CatVisPropertyShow.catVisPropertyNoShowAttr;
            try
            {
                selection.Clear();
                selection.Add(anyObjectToCheck);
                if (selection.Count > 0)
                {
                    selection.VisProperties.GetShow(out catVisPropertyShow);
                }
            }
            catch (Exception ex) { }
            isVisble = Convert.ToBoolean(catVisPropertyShow == CatVisPropertyShow.catVisPropertyShowAttr);
            return isVisble;
        }
        #endregion

        #endregion

        #region IsContentsVisible
        //public static bool IsContentsVisible(Body geoSet, Document document)
        //{
        //    if (document is null || geoSet is null) return false;
        //    bool gsIsVisible = CatiaService.IsVisibleOnScreen(document, geoSet);
        //    if (!gsIsVisible) return false;
        //    return IsContentsVisible(geoSet, document.Selection);
        //}

        public static bool IsContentsVisible(Selection documentSelection, HybridBody geoSet)
        {
            if (documentSelection is null || geoSet is null) return false;
            return IsContentsVisible(geoSet, documentSelection.Parent as Document);
        }
        public static bool IsContentsVisible(HybridBody geoSet, Selection documentSelection)
        {
            if (documentSelection is null || geoSet is null) return false;
            return IsContentsVisible(geoSet, documentSelection.Parent as Document);
        }

        public static bool IsContentsVisible(Document document, HybridBody geoSet)
        {
            return IsContentsVisible(geoSet, document);
        }
        public static bool IsContentsVisible(HybridBody geoSet, Document document)
        {
            if (document is null || geoSet is null) return false;
            if (!CatiaService.IsVisibleOnScreen(document, geoSet)) return false;

            var allObjects = new List<AnyObject>();

            Selection docSelection = document.Selection;
            string queryAllItems = "type=*,sel"; 
            docSelection.Selection.Clear();
            docSelection.Add(geoSet);
            if (docSelection.Count > 0) docSelection.Search(queryAllItems);
            for (int i = 1; i < docSelection.Count; i++)
            {
                AnyObject anyObject = docSelection.Item(i).Value as AnyObject;
                if (anyObject != null) allObjects.Add(anyObject);
            }

            foreach (var obj in allObjects)
                if (CatiaService.IsVisible(document, obj)) 
                    return true;

            return false;
        }
        #endregion

        #region IsElectricalLicenseIsAvailable
        public static bool IsElectricalLicenseIsAvailable(Document document)
        {
            bool licenseIsAvailable = true;
            if (document is null) return false;
            string query = "Name=*Electrical' ''('Restricted')'*,all";
            try
            {
                document.Selection.Clear();
                document.Selection.Search(query);
                licenseIsAvailable = document.Selection.Count == 0;
                document.Selection.Clear();
            } catch { }
            return licenseIsAvailable;
        }
        #endregion


        #region GetProductDocument
        public static ProductDocument GetProductDocument(Product product)
        {
            return GetDocument(product) as ProductDocument;
        }
        #endregion

        #region GetPartDocument
        public static PartDocument GetPartDocument(Product product)
        {
            return GetDocument(product) as PartDocument;
        }
        #endregion

        #region GetDocument
        public static Document GetDocument(Product product)
        {
            Document parentDocument = null;
            Product refProduct = null;

            try { refProduct = product.ReferenceProduct as Product; }
            catch { refProduct = null; }

            try { parentDocument = refProduct.Parent as Document; }
            catch { parentDocument = null; }

            return parentDocument;
        }
        #endregion


        #endregion
    }
}
