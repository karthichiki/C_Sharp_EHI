﻿
using AH_ESI_CATIA.CATIA;
using AH_ESI_CATIA.Models;
using INFITF;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_CATIA.Services
{
    public class CatiaDocumentsCollectionService
    {
        public static ObservableCollection<CatiaDocument> CollectOpenedDocuments()
        {
            var  listOpenedDocuments = new ObservableCollection<CatiaDocument>();

            if (!Catia.IsInitialized) return listOpenedDocuments;
            var CATIA = Catia.CATIA;
            if (CATIA.Windows.Count == 0) return listOpenedDocuments;
            Window activeWindow = null;

            try { activeWindow = CATIA.ActiveWindow; } catch { }
            foreach (INFITF.Window window in CATIA.Windows)
            {
                window.Activate();
                Document document = Catia.CATIA.ActiveDocument;
                listOpenedDocuments.Add(new CatiaDocument(listOpenedDocuments.Count + 1, document));
            }
            activeWindow?.Activate();

            return listOpenedDocuments;
        }
    }
}
