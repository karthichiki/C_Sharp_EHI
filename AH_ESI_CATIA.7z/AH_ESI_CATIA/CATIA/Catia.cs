﻿using AH_ESI_CATIA.Models;
using INFITF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace AH_ESI_CATIA.CATIA
{
    public class Catia
    {
        public static Application CATIA;

        public static List<CatiaDocument> List_session_documents;

        public static bool IsInitialized => GetCATIA();

        #region IsCATIAInitialized
        public static bool GetCATIA()
        {
            if (CATIA != null) return true;
            try
            {
                CATIA = Marshal.GetActiveObject("CATIA.Application") as Application;
            }
            catch { }
            return CATIA != null;
        }
        #endregion

        #region WorkBench IDs
        public static class WorkbenchIds
        {
            public static readonly string Assembly = "Assembly";
            public static readonly string PartDesign = "PrtCfg";
            public static readonly string Drafting = "Drw";
            public static readonly string SPAWorkbench = "SPAWorkbench";
            public static readonly string Navigator = "NavigatorWorkbench";
            public static readonly string ProductStructure = "PrsConfiguration";
            public static readonly string GenerativeShapeDesign = "CATShapeDesignWorkbench";
            public static readonly string WireframeAndSurfaceDesign = "CATHybridPartWorkbench";
        }
        #endregion

        #region Selection Copy-Paste Specials
        public static class CopyPasteSpecials
        {
            public static readonly string AsResult = "CATPrtResultWithOutLink";
            public static readonly string ResultNoLink = AsResult;
            public static readonly string LinkedResult = "CATPrtResult";
        }
        #endregion

        #region CATIA Start Commands
        public static class StartCommands
        {
            public static readonly string ProductActivation = "FrmActivate";
            public static readonly string GenerateCATPartFromProduct = "Generate CATPart from Product";
            public static readonly string DeleteUselessElements = "Delete Useless Elements";
            public static readonly string Disassemble = "Disassemble";
            public static readonly string CenterGraph = "Center graph";
            public static readonly string ReframeOn = "Reframe On";
        }
        #endregion

        #region GetTreePath
        public static string GetTreePath(AnyObject anyObject, Document document)
        {
            return GetTreePath(document, anyObject);
        }
        public static string GetTreePath(Document document, AnyObject anyObject)
        {
            string treePath = string.Empty;
            document.Selection.Clear();
            document.Selection.Add(anyObject);
            if (document.Selection.Count > 0)
            {
                treePath = anyObject.get_Name();
                try
                {
                    treePath = document.Selection.Item(1).Reference.DisplayName;
                } catch (Exception) { }
            }
            document.Selection.Clear();
            return treePath;
        }
        #endregion

    


    }
}
